package toolsformapping.errorHandling;

import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;

/**
 * NEMMappingError is an Exception class used to handle all exceptions in the NEM Mapping plugin
 * @author C404453
 *
 */
public class NEMMappingError extends Exception {
	
	
	/**
	 * 
	 * @param e wrapped exception
	 */
	public NEMMappingError(Exception e) {
		super();
		super.initCause(e);
	}
	/**
	 * @param message	Error Message
	 * @param e			Wrapped Exception
	 */
	public NEMMappingError(String message,Exception e) {
		super(message);
		super.initCause(e);
		
	}


	/**
	 * @param message Error Message
	 */
	public NEMMappingError(String message) {
		super(message);
	}
	
	/** displays this Error message in a dialog box for user awareness, also displays mapped errors
	 * @param event
	 */
	public void displayError(ExecutionEvent event)
	{
		IWorkbenchWindow window;
		try {
			Throwable e=this;
			StringBuffer errorMsgs=new StringBuffer();
			while (e!=null)
			{
				errorMsgs.append(e.getMessage()+"\n");
				e=e.getCause();
				
			}
			
			window = HandlerUtil.getActiveWorkbenchWindowChecked(event);
			MessageDialog.openError(
					window.getShell(),
					"NEM Mappinng Error",
					errorMsgs.toString());
			printStackTrace();
		} catch (ExecutionException e) {
			System.err.println("NEM Mapping had problem error handling: got "+e.getMessage()+": while handling "+getMessage());
			e.printStackTrace();
			
		}
	}
		

	/**
	 * 
	 */
	private static final long serialVersionUID = -1480947838725132340L;

}

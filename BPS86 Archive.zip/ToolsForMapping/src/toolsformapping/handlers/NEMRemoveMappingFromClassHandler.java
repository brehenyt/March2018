package toolsformapping.handlers;

import java.util.Map;
import java.util.Vector;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Usage;

import toolsformapping.dialogs.PromptSelectOperations;
import toolsformapping.errorHandling.NEMMappingError;
import toolsformapping.utils.ModelUtil;

import com.ibm.xtools.uml.navigator.ModelServerElement;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * 
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMRemoveMappingFromClassHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMRemoveMappingFromClassHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 * This removes a set of usages from a destination class. the user will be prompted to select which mapping to
	 * remove.
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		try {
			ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event)
					.getActivePage().getSelection();

			Object selObj = null;
			StringBuffer textToLog = new StringBuffer();
			if (sel instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) sel;
				selObj = ts.getFirstElement();
			}
			if (selObj instanceof ModelServerElement) {
				
				ModelServerElement mseObj = (ModelServerElement) selObj;

				Object elem = mseObj.getElement();

				if (elem instanceof Classifier) {
					//Identify the operations to remove
					final Classifier clas = (Classifier) elem;
					String uri = EcoreUtil.getURI(clas).toString();
					textToLog.append("URI of Class::>" + uri + "<\n");
					Map<String, Usage> ops = ModelUtil
							.getOperationsOnClass(clas);
					if (ops.size() == 0) {
						throw new NEMMappingError(
								"This Class is not the destination for any mappings");
					}

					//Prompt the user to select the operation to remove
					try {
						IWorkbenchWindow window;

						window = HandlerUtil
								.getActiveWorkbenchWindowChecked(event);
						PromptSelectOperations pso = new PromptSelectOperations(
								window.getShell(), ops.keySet().toArray(
										new String[0]));

						pso.setBlockOnOpen(true);
						int rc = pso.open();
						// only if OK was selected
						if (rc == 0) {
							//extract the service and mapping operation names from the selected
							final String servOp = pso.getSelection().substring(0,pso.getSelection().indexOf(","));
							final String mapOp = pso.getSelection().substring(pso.getSelection().indexOf(",")+1);
							
							//find the usages. Note this only finds usages in open models/fragments!
							final Vector<Usage> usagesToDelete=ModelUtil.getUsagesInMapping(clas,servOp,mapOp,clas.getName()+"/");
							//delete the usages associated with this mapping operation
							ModelUtil.deleteUsages(usagesToDelete, "Removing mapping related to Service Op="+servOp+", Mapping Op="+mapOp);
							
						}
					} catch (ExecutionException e) {
						throw new NEMMappingError(e);
					}

				}
			}

		} catch (NEMMappingError e) {
			e.displayError(event);
		}

		return null;
	}


}

package toolsformapping.handlers;

import java.util.Map;
import java.util.Vector;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.resources.IFile;
import org.eclipse.emf.common.util.URI;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.ui.handlers.HandlerUtil;
import org.w3c.dom.Document;

import toolsformapping.errorHandling.NEMMappingError;
import toolsformapping.utils.ClassInfo;
import toolsformapping.utils.MappingOperationElement;
import toolsformapping.utils.ModelUtil;
import toolsformapping.utils.TemplateUtil;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * 
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMProcessTemplateHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMProcessTemplateHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context. This command loads a mapping template file
	 * data into a model as a series of usages
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		try {
			ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event)
					.getActivePage().getSelection();

			Object selObj = null;
			if (sel instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) sel;
				selObj = ts.getFirstElement();
			} else {
				throw new NEMMappingError(
						"Could not process template as no template was selected");
			}
			if (selObj instanceof IFile) {
				//Item selected is a file
				IFile file = (IFile) selObj;
				if (file.getFileExtension().equals("mtp")) {
					//File Extension is "mtp"
					//load the document into a DOM document
					Document doc = TemplateUtil.createMappingTemplateDOM(file);
					//Extract the mapping operation elements
					Vector<MappingOperationElement> moes = TemplateUtil
							.processTemplateDOM(doc);
					//extract the classes
					Map<String, ClassInfo> cls = TemplateUtil
							.processTemplateForClassKeys(doc);
					//update the mapping elements with the target & source base class URIs
					UpdateMOE(moes, cls);
					ModelUtil.updateMOEAttrURIs(moes);
					ModelUtil.processMOES(moes);

				} else {
					throw new NEMMappingError(
							"Could not process template as a file with extension mtp was not selected: File extension "
									+ file.getFileExtension());

				}
			}

		} catch (NEMMappingError e) {
			e.displayError(event);
		}

		return null;
	}

	/**
	 * Updates the mapping element operations with the source and target URIs
	 * @param moes list of mapping element operations  to update
	 * @param cls
	 * @throws NEMMappingError
	 */
	private void UpdateMOE(Vector<MappingOperationElement> moes,
			Map<String, ClassInfo> cls) throws NEMMappingError {
		for (MappingOperationElement moe : moes) {
			URI suri = cls.get(moe.getSourceKey()).getUri();
			if (suri == null) {
				throw new NEMMappingError("could not find source class key"
						+ moe.getSourceKey());
			}
			moe.setSourceBase(suri);
			URI turi = cls.get(moe.getTargetKey()).getUri();
			if (turi == null) {
				throw new NEMMappingError("could not find target class key"
						+ moe.getTargetKey());
			}

			moe.setTargetBase(turi);
			if (cls.get(moe.getSourceKey()).isExternal()) {
				if (cls.get(moe.getTargetKey()).isExternal()) {
					// both are external, abort
					throw new NEMMappingError(
							"both source and target are from external classes!"
									+ moe.getSourcePath() + " to "
									+ moe.getTargetPath());
				} else {
					// make this into a pull
					moe.setDirection(MappingOperationElement.PULLDIR);
				}
			} else {
				moe.setDirection(MappingOperationElement.PUSHDIR);
			}
		}

	}

}

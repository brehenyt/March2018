package toolsformapping.handlers;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.swt.dnd.Clipboard;
import org.eclipse.swt.dnd.TextTransfer;
import org.eclipse.swt.dnd.Transfer;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.uml2.uml.Classifier;

import com.ibm.xtools.uml.navigator.ModelServerElement;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMCopyTypeURIHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMCopyTypeURIHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 * This command copies the URI of the selected element to the clipboard
	 * 
	 */
	/* (non-Javadoc)
	 * @see org.eclipse.core.commands.AbstractHandler#execute(org.eclipse.core.commands.ExecutionEvent)
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event).getActivePage().getSelection();
	
		Object selObj=null;
		if (sel instanceof ITreeSelection)
		{
			ITreeSelection ts = (ITreeSelection)sel;
			selObj=ts.getFirstElement();
		}
		if (selObj instanceof ModelServerElement)
		{
			ModelServerElement mseObj = (ModelServerElement)selObj;
			
			Object elem=mseObj.getElement();
	
			if (elem instanceof Classifier)
			{
				//selected item was a Classifier
				final Classifier clas = (Classifier) elem;
				String uri = EcoreUtil.getURI(clas).toString();
				
				
				//set the URI on the clipboard as text
				Clipboard cb=new Clipboard(Display.getCurrent());
				
				Transfer[] dataTypes;
				Object[] data=new Object[1];
				data[0]=uri;
				dataTypes=new Transfer[1];
				dataTypes[0]=TextTransfer.getInstance();
				cb.setContents(data, dataTypes);
					
				
			}
		}
	
	
		return null;
	}
	
}

package toolsformapping.handlers;

import java.util.Vector;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.NamedElement;

import toolsformapping.errorHandling.NEMMappingError;
import toolsformapping.utils.ModelUtil;
import toolsformapping.utils.TemplateUtil;

import com.ibm.xtools.uml.navigator.ModelServerElement;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * 
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMGenerateMappingTemplateHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMGenerateMappingTemplateHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context. This extracts the mapping information from
	 * a destination class and saves it to a mapping template file
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		try {
			ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event)
					.getActivePage().getSelection();

			Object selObj = null;
			if (sel instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) sel;
				selObj = ts.getFirstElement();
			}
			if (selObj instanceof ModelServerElement) {
				ModelServerElement mseObj = (ModelServerElement) selObj;

				Object elem = mseObj.getElement();
				if (elem instanceof Classifier) {
					// item selected was a Classifer
					String elemName = ((NamedElement) elem).getName();
					Classifier clas = (Classifier) elem;

					// Ask what to save as
					IWorkbenchWindow window;
					try {
						window = HandlerUtil
								.getActiveWorkbenchWindowChecked(event);
					} catch (ExecutionException e) {
						throw new NEMMappingError(e);

					}
					SaveAsDialog dd = new SaveAsDialog(window.getShell());
					dd.setOriginalName(elemName.substring(elemName
							.lastIndexOf(".") + 1) + ".mtp");
					int ret = dd.open();
					if (ret == Window.OK) {
						

						final IPath saveAs = dd.getResult();
						// make a change
							
						IFile fSaveAs = ResourcesPlugin.getWorkspace()
								.getRoot().getFile(saveAs);
						//get the paths for this classifier
						Vector<String> strs = ModelUtil.generatePaths(clas);
						
						//Save the paths in a blank mapping template file
						TemplateUtil.writeBlankTemplate(fSaveAs, strs,
								EcoreUtil.getURI(clas).toString(), "target_"
										+ clas.getName());
					}

				}
			}
		} catch (NEMMappingError e) {
			e.displayError(event);
		}

		return null;
	}

}

package toolsformapping.handlers;

import java.io.ByteArrayInputStream;
import java.util.Vector;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IPath;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.NamedElement;

import toolsformapping.errorHandling.NEMMappingError;
import toolsformapping.utils.ModelUtil;

import com.ibm.xtools.uml.navigator.ModelServerElement;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * 
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMGenerateMappingPathsHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMGenerateMappingPathsHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context.
	 * This command generates a list of paths for the class and included/subclasses attributes and saves these
	 * to a file, with the class URI
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		try {
			ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event)
					.getActivePage().getSelection();

			Object selObj = null;
			if (sel instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) sel;
				selObj = ts.getFirstElement();
			}
			if (selObj instanceof ModelServerElement) {
				ModelServerElement mseObj = (ModelServerElement) selObj;

				Object elem = mseObj.getElement();
				if (elem instanceof Classifier) {
					//selected element was a Classifier
					String elemName = ((NamedElement) elem).getName();
					Classifier clas = (Classifier) elem;

					IWorkbenchWindow window;
					try {
						window = HandlerUtil
								.getActiveWorkbenchWindowChecked(event);
					} catch (ExecutionException e) {
						throw new NEMMappingError(e);

					}
					//ask the user to select a name to save the file as
					SaveAsDialog dd = new SaveAsDialog(window.getShell());
					dd.setOriginalName(elemName.substring(elemName
							.lastIndexOf(".") + 1) + ".tpi");
					int ret = dd.open();
					// check it was OKed
					if (ret == Window.OK) {

						final IPath saveAs = dd.getResult();
						// write the path info to the file

						IFile fSaveAs = ResourcesPlugin.getWorkspace()
								.getRoot().getFile(saveAs);
						Vector<String> strs = ModelUtil.generatePaths(clas);
						writeTPI(fSaveAs,strs,clas);
		
					}

				}
			}
		} catch (NEMMappingError e) {
			e.displayError(event);
		}

		return null;
	}

	/**
	 * Writes out a path information file for this class
	 * @param output	file to output
	 * @param strs		the paths to save
	 * @param clas		the Classifier to store the URI of
	 * @throws NEMMappingError
	 */
	private static void writeTPI(IFile output, Vector<String> strs, Classifier clas) throws NEMMappingError {
		try{
		StringBuffer sb=new StringBuffer();
		sb.append("Type Name "+clas.getQualifiedName());
		sb.append("\n");
		sb.append("===================");
		sb.append("\n");
		sb.append("\n");
		sb.append("Class URI="+EcoreUtil.getURI(clas));
		sb.append("\n");
		sb.append("\n");
		sb.append("Paths of attributes/fields\n");
		for (String str:strs)
		{
			sb.append(str);
			sb.append("\n");
		}
		if (output.exists()) {
			output.delete(true, new NullProgressMonitor());
		}
		output.create(new ByteArrayInputStream(sb.toString().getBytes()), true,
				new NullProgressMonitor());
		}
		catch( CoreException e)
		{
			throw new NEMMappingError("Problem saving file "+output.getName(),e);
		}
		
	}
	

}

package toolsformapping.handlers;

import java.io.ByteArrayInputStream;
import java.util.Map;
import java.util.Vector;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IPath;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.ITreeSelection;
import org.eclipse.jface.window.Window;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.dialogs.SaveAsDialog;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.Usage;
import org.w3c.dom.Document;

import toolsformapping.dialogs.PromptSelectOperations;
import toolsformapping.errorHandling.NEMMappingError;
import toolsformapping.utils.ClassInfo;
import toolsformapping.utils.MappingOperationElement;
import toolsformapping.utils.ModelUtil;
import toolsformapping.utils.TemplateUtil;

import com.ibm.xtools.uml.navigator.ModelServerElement;

/**
 * Our sample handler extends AbstractHandler, an IHandler base class.
 * 
 * @see org.eclipse.core.commands.IHandler
 * @see org.eclipse.core.commands.AbstractHandler
 */
public class NEMCreateMappingTemplateFromTypeHandler extends AbstractHandler {
	/**
	 * The constructor.
	 */
	public NEMCreateMappingTemplateFromTypeHandler() {
	}

	/**
	 * the command has been executed, so extract extract the needed information
	 * from the application context. This command creates a sources blank
	 * mapping template for the selected destination class
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.eclipse.core.commands.AbstractHandler#execute(org.eclipse.core.commands
	 * .ExecutionEvent)
	 */
	@Override
	public Object execute(ExecutionEvent event) {
		try {
			ISelection sel = HandlerUtil.getActiveWorkbenchWindow(event)
					.getActivePage().getSelection();

			Object selObj = null;
			if (sel instanceof ITreeSelection) {
				ITreeSelection ts = (ITreeSelection) sel;
				selObj = ts.getFirstElement();
			}
			if (selObj instanceof ModelServerElement) {
				ModelServerElement mseObj = (ModelServerElement) selObj;

				Object elem = mseObj.getElement();

				if (elem instanceof Classifier) {
					//The selected item is a classifier
					final Classifier clas = (Classifier) elem;
		
					Map<String, Usage> ops = ModelUtil
							.getOperationsOnClass(clas);
					if (ops.size() == 0) {
						throw new NEMMappingError(
								"This Class is not the destination for any mappings, you may need to open other models");
					}

					try {
						//Prompt the user to select the mapping
						IWorkbenchWindow window;

						window = HandlerUtil
								.getActiveWorkbenchWindowChecked(event);
						PromptSelectOperations pso = new PromptSelectOperations(
								window.getShell(), ops.keySet().toArray(
										new String[0]));

						pso.setBlockOnOpen(true);
						int rc = pso.open();
						// only if OK was selected continue
						if (rc == Window.OK) {
							//identify the selected service and mapping operation
							String servOp = pso.getSelection().substring(0,
									pso.getSelection().indexOf(","));
							String mapOp = pso.getSelection().substring(
									pso.getSelection().indexOf(",") + 1);
							//get the "usage"s for this mapping operation
							Vector<Usage> usagesToStore = ModelUtil
									.getUsagesInMapping(clas, servOp, mapOp,
											clas.getName() + "/");
							// get class info for this mapping operation
							Vector<ClassInfo> cis = ModelUtil
									.getClassInfo(usagesToStore);
							// convert the "usage"s into mapping element operations
							Vector<MappingOperationElement> moes = ModelUtil
									.getMOEs(usagesToStore);
							
							//Create a DOM document represenation of the mapping template
							Document doc = TemplateUtil.assembleTemplate(cis,
									moes);
							// ASk the user to choose a file to save as.
							IWorkbenchWindow saveAsWindow;
							try {
								saveAsWindow = HandlerUtil
										.getActiveWorkbenchWindowChecked(event);
							} catch (ExecutionException e) {
								throw new NEMMappingError(e);

							}
							SaveAsDialog dd = new SaveAsDialog(
									saveAsWindow.getShell());
							dd.setOriginalName(cis.get(0).getName() + ".mtp");
							dd.setBlockOnOpen(true);
							int ret = dd.open();
							if (ret == Window.OK) {
								//save the mapping template file
								IPath saveAs = dd.getResult();
								IFile fSaveAs = ResourcesPlugin.getWorkspace()
										.getRoot().getFile(saveAs);
								TemplateUtil.forceWriteFile(fSaveAs,
										new ByteArrayInputStream(TemplateUtil
												.getStringFromDoc(doc)
												.getBytes()));
							}
						}
					} catch (ExecutionException e) {
						throw new NEMMappingError(e);
					}

				}
			}

		} catch (NEMMappingError e) {
			e.displayError(event);
		}

		return null;
	}

}

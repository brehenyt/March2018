package toolsformapping.proptests;

import org.eclipse.core.expressions.PropertyTester;

import com.ibm.xtools.uml.navigator.ModelServerElement;

public class UmlTest extends PropertyTester {

	/** 
	 *  This test checks if the UML element is an instance of the expected type
	 */
	/* (non-Javadoc)
	 * @see org.eclipse.core.expressions.IPropertyTester#test(java.lang.Object, java.lang.String, java.lang.Object[], java.lang.Object)
	 */
	@Override
	public boolean test(Object receiver, String property, Object[] args,
			Object expectedValue) {

		boolean ret = false;
		if (expectedValue instanceof String) {
			String evStr = (String) expectedValue;

			if (property.equals("ElementInstanceOf")) {

				if (receiver instanceof ModelServerElement) {
					ModelServerElement mseRec = (ModelServerElement) receiver;

					try {
						ret = this.getClass().getClassLoader().loadClass(evStr)
								.isInstance(mseRec.getElement());
					} catch (ClassNotFoundException e) {

						System.err.println(" Could not load class  " + evStr);
						e.printStackTrace();
					}
				}
			}
		}

		return ret;
	}

}

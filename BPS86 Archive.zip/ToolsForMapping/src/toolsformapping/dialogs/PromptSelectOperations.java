package toolsformapping.dialogs;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.graphics.Point;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.List;
import org.eclipse.swt.widgets.Shell;

public class PromptSelectOperations extends Dialog {

	private String selected;
	private String[] operations;

	public PromptSelectOperations(Shell parentShell, String[] operations_p) {
		super(parentShell);
		operations = operations_p;
	}

	/*
	 * (non-Javadoc)
	 * @see
	 * org.eclipse.jface.dialogs.Dialog#createDialogArea(org.eclipse.swt.widgets
	 * .Composite)
	 */
	@Override
	protected Control createDialogArea(Composite parent) {
		Composite container = (Composite) super.createDialogArea(parent);
		final List list = new List(container, SWT.SINGLE);
		list.setItems(operations);
		list.select(0);
		selected = operations[0];
		list.setSize(list.computeSize(SWT.DEFAULT, SWT.DEFAULT));

		list.setLayoutData(new GridData(SWT.BEGINNING, SWT.CENTER, false, false));

		list.addSelectionListener(new SelectionAdapter() {
			@Override
			public void widgetSelected(SelectionEvent e) {
				selected = operations[list.getSelectionIndex()];
			}
		});

		return container;
	}

	// overriding this methods allows you to set the
	// title of the custom dialog
	@Override
	protected void configureShell(Shell newShell) {
		super.configureShell(newShell);
		newShell.setText("Select Operation");
	}

	@Override
	protected Point getInitialSize() {
		return new Point(450, 300);
	}

	public String getSelection() {

		return selected;
	}

}
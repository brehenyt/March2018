package toolsformapping.utils;

import org.eclipse.emf.common.util.URI;

/**
 * This is a POJO representing the Classifers (Classes or Datatypes)
 * which are used in a mapping
 * @author C404453
 *
 */
public class ClassInfo {
	
	private String Name;		//Class Name
	private URI Uri;			//Class URI in the Model
	private boolean External;	//If this model is considered external, so NEM DC should not add relationships to the model
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public URI getUri() {
		return Uri;
	}
	public void setUri(URI uri) {
		Uri = uri;
	}
	public boolean isExternal() {
		return External;
	}
	public void setExternal(boolean external) {
		External = external;
	}

}

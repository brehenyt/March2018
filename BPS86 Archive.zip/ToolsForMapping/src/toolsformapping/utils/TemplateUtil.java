package toolsformapping.utils;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.xml.namespace.NamespaceContext;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.emf.common.util.URI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import toolsformapping.errorHandling.NEMMappingError;

/**
 * This is a library of utility methods & literals to handle template documents.
 * 
 * @author C404453
 * 
 */
public abstract class TemplateUtil {

	private static final String TARGET_TEMPLATE_LOC = "platform:/plugin/ToolsForMapping/files/TargetTemplate.xml";
	private static final String BASE_TEMPLATE_LOC = "platform:/plugin/ToolsForMapping/files/BaseTemplate.xml";

	public static final String TEMPLATE_NS = "http://www.nationwide.co.uk/NEMDC/Tools/MappingTemplate";
	public static final String TEMPLATE_NS_PREFIX = "tns";

	private static String baseTemplate = null;
	private static String targetTemplate = null;

	/**
	 * Reads a file and process it into a DOM Document
	 * 
	 * @param file
	 *            the file to read
	 * @return a DOM Document containing the read file
	 * @throws NEMMappingError
	 */
	public static Document createMappingTemplateDOM(IFile file)
			throws NEMMappingError {

		Document doc = null;
		InputStream is = null;
		try {
			is = file.getContents();

			doc = LocationHandler.parse(is);
		} catch (ParserConfigurationException e) {
			throw new NEMMappingError("Problem parseing mapping template", e);
		} catch (SAXException e) {
			String str = "";
			if (e instanceof SAXParseException) {
				str = "line number=" + ((SAXParseException) e).getLineNumber()
						+ "  Column number"
						+ ((SAXParseException) e).getColumnNumber();
			}
			throw new NEMMappingError("Problem parseing mapping template ::"
					+ str + "::", e);
		} catch (IOException e) {
			throw new NEMMappingError("Problem parseing mapping template", e);
		} catch (CoreException e) {
			throw new NEMMappingError("Problem parseing mapping template", e);
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException e) {
					throw new NEMMappingError(
							"Problem parseing mapping template", e);
				}
			}
		}

		return doc;
	}

	/**
	 * write a blank Mapping template file
	 * 
	 * @param output
	 *            file to output
	 * @param targetPaths
	 *            the paths to output
	 * @param targetClassURI
	 *            The URI of the target class
	 * @param targetClassKey
	 *            The key to represent the target class in the file.
	 * @throws NEMMappingError
	 */
	public static void writeBlankTemplate(IFile output,
			Vector<String> targetPaths, String targetClassURI,
			String targetClassKey) throws NEMMappingError {

		String base = getBaseTemplate().replace("$$$TARGETCLASSURL$$$",
				targetClassURI).replace("$$$TARGETCLASSKEY$$$", targetClassKey);
		String target = getTargetTemplate();
		StringBuffer targets = new StringBuffer();
		for (String targetPath : targetPaths) {
			targets.append(target.replace("$$$TARGETPATH$$$", targetPath)
					.replace("$$$TARGETCLASSKEY$$$", targetClassKey));
		}
		String strToSave = base.replace("$$$TARGETS$$$", targets.toString());
		if (output.exists()) {
			try {
				output.delete(true, new NullProgressMonitor());
			} catch (CoreException e) {
				throw new NEMMappingError("Could not delete file "
						+ output.getName(), e);
			}
		}
		try {
			output.create(new ByteArrayInputStream(strToSave.getBytes()), true,
					new NullProgressMonitor());
		} catch (CoreException e) {
			throw new NEMMappingError("Could not create file "
					+ output.getName(), e);
		}

	}

	/**
	 * Write a file, if it already exists then delete this first
	 * 
	 * @param output
	 *            file to output
	 * @param is
	 *            data to write to file
	 * @throws NEMMappingError
	 */
	public static void forceWriteFile(IFile output, InputStream is)
			throws NEMMappingError {
		try {
			if (output.exists()) {

				output.delete(true, new NullProgressMonitor());

			}
			output.create(is, true, new NullProgressMonitor());
		} catch (CoreException e) {
			throw new NEMMappingError("Could not create file "
					+ output.getName());
		}

	}

	/**
	 * load the base template from a resource
	 * 
	 * @return the base template string
	 * @throws NEMMappingError
	 */
	private static String getBaseTemplate() throws NEMMappingError {
		StringBuffer all = new StringBuffer();
		if (baseTemplate == null) {
			InputStream is = null;
			try {
				URL templateBaseURL = new URL(BASE_TEMPLATE_LOC);
				is = templateBaseURL.openConnection().getInputStream();
				BufferedReader in = new BufferedReader(
						new InputStreamReader(is));

				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					all.append(inputLine);
					all.append("\n");
				}

			} catch (IOException e) {
				throw new NEMMappingError("Problem reading "
						+ BASE_TEMPLATE_LOC, e);
			} finally {
				try {
					if (is != null) {
						is.close();
					}
				} catch (IOException e) {
					throw new NEMMappingError("Problem reading "
							+ BASE_TEMPLATE_LOC, e);
				}
			}
			baseTemplate = all.toString();
		}
		return baseTemplate;
	}

	/**
	 * load the target template from a resource
	 * 
	 * @return the target template
	 * @throws NEMMappingError
	 */
	private static String getTargetTemplate() throws NEMMappingError {
		StringBuffer all = new StringBuffer();
		if (targetTemplate == null) {
			InputStream is = null;
			try {
				URL templateBaseURL = new URL(TARGET_TEMPLATE_LOC);
				is = templateBaseURL.openConnection().getInputStream();
				BufferedReader in = new BufferedReader(
						new InputStreamReader(is));

				String inputLine;
				while ((inputLine = in.readLine()) != null) {
					all.append(inputLine);
					all.append("\n");
				}

			} catch (IOException e) {
				throw new NEMMappingError("Problem reading "
						+ TARGET_TEMPLATE_LOC, e);
			} finally {
				if (is != null) {
					try {
						is.close();
					} catch (IOException e) {
						throw new NEMMappingError("Problem reading "
								+ TARGET_TEMPLATE_LOC, e);
					}
				}
			}
			targetTemplate = all.toString();
		}
		return targetTemplate;
	}

	//Absolute path of the source keys in mapping template
	private static String ABSXPATHSOURCEKEY = "/"+TEMPLATE_NS_PREFIX+":MappingTemplate/"+TEMPLATE_NS_PREFIX+":Target/"+TEMPLATE_NS_PREFIX+":Source/"+TEMPLATE_NS_PREFIX+":SourceKey";
	
	//relative paths from source key
	private static String RELXPATHSOURCEPATH = "../" + TEMPLATE_NS_PREFIX
			+ ":SourcePath";
	private static String RELXPATHTARGETKEY = "../../" + TEMPLATE_NS_PREFIX
			+ ":TargetKey";
	private static String RELXPATHTARGETPATH = "../../" + TEMPLATE_NS_PREFIX
			+ ":TargetPath";
	private static String RELXPATHTRANSFORMATION = "../../"
			+ TEMPLATE_NS_PREFIX + ":Transformation";
	private static String RELXPATHCONDITION = "../../" + TEMPLATE_NS_PREFIX
			+ ":Condition";
	private static String RELXPATHMAPPINGOPERATION = "../../../"
			+ TEMPLATE_NS_PREFIX + ":MappingOperation";
	private static String RELXPATHSERVICEOPERATION = "../../../"
			+ TEMPLATE_NS_PREFIX + ":ServiceOperation";

	/**
	 * Take a DOM Document representation of a Template and output the list of
	 * Mapping operation Elements
	 * 
	 * @param doc
	 *            DOM document representing a Template
	 * @return set of mapping operation elements
	 * @throws NEMMappingError
	 */
	public static Vector<MappingOperationElement> processTemplateDOM(
			Document doc) throws NEMMappingError {
		Vector<MappingOperationElement> ret = new Vector<MappingOperationElement>();


			XPath xpath = XPathFactory.newInstance().newXPath();
			NamespaceContext nc = new ToolsNamespaceContext();
			xpath.setNamespaceContext(nc);
			NodeList nodeset;
			try {
				nodeset = (NodeList) xpath.evaluate(
						ABSXPATHSOURCEKEY,
						doc.getDocumentElement(), XPathConstants.NODESET);
			} catch (XPathExpressionException e) {
				String context = LocationHandler.getTemplateLocation(doc.getDocumentElement());
				throw new NEMMappingError("Problem processing Mapping Operations: From element "
						+ doc.getDocumentElement().getNodeName() + " " + context
						+ " to find path " + ABSXPATHSOURCEKEY, e);
			}
			for (int n = 0; n < nodeset.getLength(); n++) {

				MappingOperationElement moe = new MappingOperationElement();
				Node sknode = nodeset.item(n);
				moe.setSourceKey(sknode.getTextContent());
				Node spnode=getXpath(xpath,RELXPATHSOURCEPATH,sknode,false);
				moe.setSourcePath(spnode.getTextContent());
				Node tknode=getXpath(xpath,RELXPATHTARGETKEY,sknode,false);
				moe.setTargetKey(tknode.getTextContent());
				Node tpnode=getXpath(xpath,RELXPATHTARGETPATH,sknode,false);
				moe.setTargetPath(tpnode.getTextContent());
				Node trnode=getXpath(xpath,RELXPATHTRANSFORMATION,sknode,true);
				if (trnode != null) {
					moe.setTransformation(trnode.getTextContent());
				}
				Node cdnode=getXpath(xpath,RELXPATHCONDITION,sknode,true);
				if (cdnode != null) {
					moe.setCondition(cdnode.getTextContent());
				}
				Node monode=getXpath(xpath,RELXPATHMAPPINGOPERATION,sknode,false);
				moe.setMappingOperation(monode.getTextContent());
				Node sonode=getXpath(xpath,RELXPATHSERVICEOPERATION,sknode,false);
				moe.setServiceOperation(sonode.getTextContent());
				ret.add(moe);

			}
		
		return ret;

	}

	// Note this is not threadsafe, turn into a thread local
	private static String XpathContext = null;

	private static Node getXpath(XPath xpath, String path, Node node,
			boolean nullAllowed) throws NEMMappingError {
		String context = LocationHandler.getTemplateLocation(node);

		Node ret;
		try {
			ret = (Node) xpath.evaluate(path, node, XPathConstants.NODE);
		} catch (XPathExpressionException e) {
			throw new NEMMappingError(
					"Problem processing Mapping Operations: From element "
							+ node.getNodeName() + " " + context
							+ " to find path " + path, e);
		}
		if (nullAllowed==false && ret==null)
		{
			throw new NEMMappingError(
					"Problem processing Mapping Operations: From element "
							+ node.getNodeName() + " " + context
							+ " to find path " + path + "was not found");
		}
			
		return ret;
	}

	/**
	 * Process a DOM Document representation of a template and extract the Class
	 * info
	 * 
	 * @param doc
	 *            DOM Document representation of a template
	 * @return a set of Class info objects representing the base classes
	 * @throws NEMMappingError
	 */
	public static Map<String, ClassInfo> processTemplateForClassKeys(
			Document doc) throws NEMMappingError {
		Map<String, ClassInfo> ret = new HashMap<String, ClassInfo>();
		XPath xpath = XPathFactory.newInstance().newXPath();

		NamespaceContext nc = new ToolsNamespaceContext();
		xpath.setNamespaceContext(nc);

		NodeList nodeset;
		try {
			nodeset = (NodeList) xpath.evaluate(
					"/tns:MappingTemplate/tns:Class/tns:ClassKey",
					doc.getDocumentElement(), XPathConstants.NODESET);
		} catch (XPathExpressionException e) {
			throw new NEMMappingError(e);
		}
		for (int n = 0; n < nodeset.getLength(); n++) {
			Node cknode = nodeset.item(n);
			Node cunode;
			URI uri;
			Node eznode;
			try {
				cunode = (Node) xpath.evaluate("../tns:ClassURL", cknode,
						XPathConstants.NODE);
				if (cunode == null) {
					throw new NEMMappingError(
							"'ClassURL' field not found for  "
									+ cknode.getNodeName() + ":"
									+ cknode.getTextContent());
				}

				uri = URI.createURI(cunode.getTextContent());
				eznode = (Node) xpath.evaluate("../tns:External", cknode,
						XPathConstants.NODE);
				if (eznode == null) {
					throw new NEMMappingError(
							"'External' field not found for  "
									+ cknode.getNodeName() + ":"
									+ cknode.getTextContent());
				}
			} catch (XPathExpressionException e) {
				throw new NEMMappingError(e);
			}
			ClassInfo ci = new ClassInfo();
			ci.setName(cknode.getTextContent());
			ci.setUri(uri);
			ci.setExternal(eznode.getTextContent().toLowerCase().equals("true"));
			ret.put(cknode.getTextContent(), ci);
		}
		return ret;
	}

	/**
	 * Assemble a DOM Document representation of a Template
	 * 
	 * @param cis
	 *            set of class info objects representing the base classes
	 * @param moes
	 *            set of message operation elements
	 * @return a DOM Document containing the Template data
	 * @throws NEMMappingError
	 */
	public static Document assembleTemplate(Vector<ClassInfo> cis,
			Vector<MappingOperationElement> moes) throws NEMMappingError {
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db;
		Document doc;
		XPath xpath = XPathFactory.newInstance().newXPath();
		NamespaceContext nc = new ToolsNamespaceContext();
		xpath.setNamespaceContext(nc);
		try {
			String so = moes.get(0).getServiceOperation();
			String mo = moes.get(0).getMappingOperation();
			db = dbf.newDocumentBuilder();
			doc = db.getDOMImplementation().createDocument(TEMPLATE_NS,
					"MappingTemplate", null);
			Element root = doc.getDocumentElement();
			Element soElm = doc
					.createElementNS(TEMPLATE_NS, "ServiceOperation");
			soElm.setTextContent(so);
			root.appendChild(soElm);
			Element moElm = doc
					.createElementNS(TEMPLATE_NS, "MappingOperation");
			moElm.setTextContent(mo);
			root.appendChild(moElm);
			for (ClassInfo ci : cis) {
				Element clElm = doc.createElementNS(TEMPLATE_NS, "Class");
				Element clKeyElm = doc.createElementNS(TEMPLATE_NS, "ClassKey");
				Element clURIElm = doc.createElementNS(TEMPLATE_NS, "ClassURL");
				Element clExtElm = doc.createElementNS(TEMPLATE_NS, "External");
				clKeyElm.setTextContent(ci.getName());
				clURIElm.setTextContent(ci.getUri().toString());
				clExtElm.setTextContent(ci.isExternal() ? "true" : "false");
				clElm.appendChild(clKeyElm);
				clElm.appendChild(clURIElm);
				clElm.appendChild(clExtElm);
				root.appendChild(clElm);

			}
			for (MappingOperationElement moe : moes) {

				// Do Target Group
				String query = "/tns:MappingTemplate/tns:Target[./tns:TargetPath = '"
						+ moe.getTargetPath()
						+ "' and ./tns:TargetKey = '"
						+ moe.getTargetKey() + "' ]";
				Element tarElem = (Element) xpath.evaluate(query, doc,
						XPathConstants.NODE);
				if (tarElem == null) {
					// Target does not exist so create it
					tarElem = doc.createElementNS(TEMPLATE_NS, "Target");
					Element tarKeyElem = doc.createElementNS(TEMPLATE_NS,
							"TargetKey");
					Element tarPathElem = doc.createElementNS(TEMPLATE_NS,
							"TargetPath");
					Element tranElem = doc.createElementNS(TEMPLATE_NS,
							"Transformation");
					Element condElem = doc.createElementNS(TEMPLATE_NS,
							"Condition");
					root.appendChild(tarElem);
					tarKeyElem.setTextContent(moe.getTargetKey());
					tarElem.appendChild(tarKeyElem);
					tarPathElem.setTextContent(moe.getTargetPath());
					tarElem.appendChild(tarPathElem);
					if (moe.getTransformation() != null) {
						tranElem.setTextContent(moe.getTransformation());
						tarElem.appendChild(tranElem);
					}
					if (moe.getCondition() != null) {
						condElem.setTextContent(moe.getCondition());
						tarElem.appendChild(condElem);
					}

				}
				// Do sources Group
				Element sorElem = doc.createElement("Source");
				Element sorKeyElem = doc.createElement("SourceKey");
				Element sorPathElem = doc.createElement("SourcePath");
				sorKeyElem.setTextContent(moe.getSourceKey());
				sorPathElem.setTextContent(moe.getSourcePath());
				tarElem.appendChild(sorElem);
				sorElem.appendChild(sorKeyElem);
				sorElem.appendChild(sorPathElem);

			}

		} catch (ParserConfigurationException | XPathExpressionException e) {
			throw new NEMMappingError("Error creating mapping template", e);
		}

		return doc;

	}

	/**
	 * Serialises a dom document into a string pretty prints and indents the
	 * text
	 * 
	 * @param doc
	 * @return text of xml dom document
	 * @throws NEMMappingError
	 */
	public static String getStringFromDoc(Document doc) throws NEMMappingError {
		try {
			DOMSource ds = new DOMSource(doc);
			StringWriter sw = new StringWriter();
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer t = tf.newTransformer();
			// These set up pretty printing in supporting DOM implementations
			t.setOutputProperty(OutputKeys.INDENT, "yes");
			t.setOutputProperty("{http://xml.apache.org/xslt}indent-amount",
					"2");
			t.transform(ds, new StreamResult(sw));
			sw.flush();
			return sw.toString();
		} catch (TransformerException e) {
			throw new NEMMappingError("Problem writing out an XML document", e);

		}

	}
}

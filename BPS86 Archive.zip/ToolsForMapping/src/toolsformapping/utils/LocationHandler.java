package toolsformapping.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Stack;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class LocationHandler extends DefaultHandler {

	private Stack<String> path = new Stack<String>();
	private Stack<HashMap<String, Integer>> countChildElems = new Stack<HashMap<String, Integer>>();
	private Stack<String> pathNS = new Stack<String>();
	private Stack<Integer> elementNumber = new Stack<Integer>();
	private Document doc;
	private Locator loc;

	public static final String UD_STARTLINE = "FileStartLine";
	public static final String UD_STARTCOL = "FileStartColumn";
	public static final String UD_ENDLINE = "FileEndLine";
	public static final String UD_ENDCOL = "FileEndColumn";

	public void setDocument(Document doc_p) {
		doc = doc_p;
	}

	private Element FindElement() {
		int n = 0;
		Element elementN = doc.getDocumentElement();
		boolean root = true;
		boolean found = true;
		for (String element : path) {
			String ns = pathNS.get(n);
			if (!root) {
				NodeList nl;
				if (ns.equals("")) {
					nl = elementN.getElementsByTagName(element);
				} else {
					nl = elementN.getElementsByTagNameNS(ns, element);
				}
				Node node = nl.item(elementNumber.get(n)-1);
				if (node != null && node instanceof Element) {
					elementN = (Element) node;
				} else {
					// if node is null or not an element
					found = false;
					break;
				}
			}else
			{//root
				if (!(elementN.getLocalName().equals(element) &&
						(elementN.getNamespaceURI()==null?"":elementN.getNamespaceURI()).equals(ns)))
				{
					found=false;
					break;
				}
			}
			
			root = false;
			n++;
		}
		if (found == false) {
			elementN = null;
		}
		return elementN;
	}

	@Override
	public void endElement(String uri, String localName, String qName)
			throws SAXException {
		


		Element elem = FindElement();
		elem.setUserData(UD_ENDLINE, loc.getLineNumber(), null);
		elem.setUserData(UD_ENDCOL, loc.getColumnNumber(), null);

		path.pop();
		pathNS.pop();
		countChildElems.pop();
		elementNumber.pop();

		super.endElement(uri, localName, qName);
	}

	@Override
	public void startElement(String uri, String localName, String qName,
			Attributes attrs) throws SAXException {

		HashMap<String, Integer> parent = null;
		if (countChildElems.size() > 0) {
			parent = countChildElems.lastElement();
		}
		countChildElems.add(new HashMap<String, Integer>());
		path.add(localName);
		pathNS.add(uri);
		Integer count;
		if (parent != null) {
			// not the root, record this element's count
			count = parent.get(localName);
			if (count == null) {
				count = 0;
			}
			count++;
			parent.put(localName, count);
		} else {
			count = 1;
		}
		elementNumber.add(count);
		Element elem = FindElement();
		elem.setUserData(UD_STARTLINE, loc.getLineNumber(), null);
		elem.setUserData(UD_STARTCOL, loc.getColumnNumber(), null);

		super.startElement(uri, localName, qName, attrs);
	}

	@Override
	public void startDocument() throws SAXException {
		// zero the path
		path = new Stack<String>();
		pathNS = new Stack<String>();
		countChildElems = new Stack<HashMap<String, Integer>>();
		elementNumber = new Stack<Integer>();
		super.startDocument();
	}

	@Override
	public void setDocumentLocator(Locator locator) {
		loc = locator;
		super.setDocumentLocator(locator);
	}

	public static Document parse(InputStream iss) throws SAXException,
			IOException, ParserConfigurationException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();

		int nRead;
		byte[] data = new byte[1024*16];// 16k buffer.

		while ((nRead = iss.read(data, 0, data.length)) != -1) {
			buffer.write(data, 0, nRead);
		}

		buffer.flush();

		ByteArrayInputStream in1 = new ByteArrayInputStream(
				buffer.toByteArray());
		ByteArrayInputStream in2 = new ByteArrayInputStream(
				buffer.toByteArray());

		// read the dom model

		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		dbf.setNamespaceAware(true);
		DocumentBuilder db;
		Document doc = null;
		db = dbf.newDocumentBuilder();
		doc = db.parse(in1);

		LocationHandler lh = new LocationHandler();
		lh.setDocument(doc);
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(true);
		SAXParser saxParser = factory.newSAXParser();
		saxParser.parse(in2, lh);
		return doc;
	}
	
	public static String getTemplateLocation(Node templateNode) {
		Integer startLine = (Integer) templateNode.getUserData(LocationHandler.UD_STARTLINE);
		Integer startCol=(Integer) templateNode.getUserData(LocationHandler.UD_STARTCOL);
		Integer endLine=(Integer) templateNode.getUserData(LocationHandler.UD_ENDLINE);
		Integer endCol=(Integer) templateNode.getUserData(LocationHandler.UD_ENDCOL);
		String ret=null;
		if (startLine!=null
				&& startCol!=null
				&& endLine!=null
				&& endCol!=null)
		{
			ret="starting at line "+startLine+" column "+startCol+", ending at line "+endLine+" column "+endCol;
		}
			
		return ret;
	}
	

}

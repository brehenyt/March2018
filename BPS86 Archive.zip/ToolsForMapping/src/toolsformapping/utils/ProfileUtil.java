package toolsformapping.utils;

/**
 * Contains literals representing the stereotype infomation used by NEM Mapping
 * @author C404453
 *
 */
public class ProfileUtil {
	
	public static String PROFILE_NAME="NEMMapSoRTOM::mapSoR_TOM";
	public static String PP_TRANSFORMATION="transformation";
	public static String PP_MAPPING_OPERATION="mappingOperation";
	public static String PP_SERVICE_OPERATION="serviceOperation";
	public static String PP_TAREGT_MSG_PATH="targetMessagePath";
	public static String PP_SOURCE_MSG_PATH="sourceMessagePath";
	public static String PP_CONDITION="condition";
	public static String PP_PUSH="push";
	

}

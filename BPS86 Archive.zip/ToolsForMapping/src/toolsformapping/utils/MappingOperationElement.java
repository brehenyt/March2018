package toolsformapping.utils;

import org.eclipse.emf.common.util.URI;

/**
 * This class represents each individual mapping from a source attribute to a target attribute
 * This will be represented in the model by a usage element
 * @author C404453
 *
 */
public class MappingOperationElement {
	
	public static String PULLDIR="Pull";
	public static String PUSHDIR="Push";
	
	private String direction;
	private URI sourceAttr;
	private URI sourceBase;
	private String sourcePath;
	private String sourceKey;
	private URI targetAttr;
	private URI targetBase;
	private String targetPath;
	private String targetKey;
	private String condition;
	private String transformation;
	private String mappingOperation;
	private String serviceOperation;
	public URI getSourceAttr() {
		return sourceAttr;
	}
	public void setSourceAttr(URI sourceAttr) {
		this.sourceAttr = sourceAttr;
	}
	public URI getSourceBase() {
		return sourceBase;
	}
	public void setSourceBase(URI sourceBase) {
		this.sourceBase = sourceBase;
	}
	public String getSourcePath() {
		return sourcePath;
	}
	public void setSourcePath(String sourcePath) {
		this.sourcePath = sourcePath;
	}
	public URI getTargetAttr() {
		return targetAttr;
	}
	public void setTargetAttr(URI targetAttr) {
		this.targetAttr = targetAttr;
	}
	public URI getTargetBase() {
		return targetBase;
	}
	public void setTargetBase(URI targetBase) {
		this.targetBase = targetBase;
	}

	public String getCondition() {
		return condition;
	}
	public void setCondition(String condition) {
		this.condition = condition;
	}

	public String getMappingOperation() {
		return mappingOperation;
	}
	public void setMappingOperation(String mappingOperation) {
		this.mappingOperation = mappingOperation;
	}
	public String getServiceOperation() {
		return serviceOperation;
	}
	public void setServiceOperation(String serviceOperation) {
		this.serviceOperation = serviceOperation;
	}
	public String getSourceKey() {
		return sourceKey;
	}
	public void setSourceKey(String sourceKey) {
		this.sourceKey = sourceKey;
	}
	public String getTargetPath() {
		return targetPath;
	}
	public void setTargetPath(String targetPath) {
		this.targetPath = targetPath;
	}
	public String getTargetKey() {
		return targetKey;
	}
	public void setTargetKey(String targetKey) {
		this.targetKey = targetKey;
	}
	public String getTransformation() {
		return transformation;
	}
	public void setTransformation(String transformation) {
		this.transformation = transformation;
	}
	public String getDirection() {
		return direction;
	}
	public void setDirection(String direction) {
		this.direction = direction;
	}

}

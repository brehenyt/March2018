package toolsformapping.utils;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.xml.namespace.NamespaceContext;

/**
 * Used to resolve namespaces for navigating xpaths in mapping template 
 * @author C404453
 *
 */
public class ToolsNamespaceContext implements NamespaceContext {
	
	private static Map<String,String> NAMESPACEMAP;
	private static Map<String,String> PREFIXMAP;
	static
	{
		NAMESPACEMAP=new HashMap<String, String>();
		NAMESPACEMAP.put(TemplateUtil.TEMPLATE_NS_PREFIX, TemplateUtil.TEMPLATE_NS);
		PREFIXMAP=new HashMap<String, String>();
		for (String key:NAMESPACEMAP.keySet())
		{
			PREFIXMAP.put(NAMESPACEMAP.get(key), key);
		}
	}
	

	@Override
	public String getNamespaceURI(String prefix) {
		
		return NAMESPACEMAP.get(prefix);
	}

	@Override
	public String getPrefix(String ns) {
		return PREFIXMAP.get(ns);
	}

	@Override
	public Iterator<String> getPrefixes(String arg0) {
		return NAMESPACEMAP.keySet().iterator();
	}

}

package toolsformapping.utils;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Vector;

import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.common.util.WrappedException;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.Resource.Factory;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.transaction.RecordingCommand;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.uml2.uml.Class;
import org.eclipse.uml2.uml.Classifier;
import org.eclipse.uml2.uml.DataType;
import org.eclipse.uml2.uml.DirectedRelationship;
import org.eclipse.uml2.uml.Element;
import org.eclipse.uml2.uml.Generalization;
import org.eclipse.uml2.uml.NamedElement;
import org.eclipse.uml2.uml.Stereotype;
import org.eclipse.uml2.uml.TypedElement;
import org.eclipse.uml2.uml.Usage;

import toolsformapping.errorHandling.NEMMappingError;

import com.ibm.xtools.modeler.ui.UMLModeler;

public abstract class ModelUtil {

	// Used to handler error passing between inner classes
	private static NEMMappingError passBack;

	/**
	 * Find all the attribute paths
	 * 
	 * @param cl
	 *            find all of the attribute paths for this Classifier
	 * @return a set of paths of attributes
	 * @throws NEMMappingError
	 */
	public static Vector<String> generatePaths(Classifier cl)
			throws NEMMappingError {
		Vector<String> strs = new Vector<String>();
		HashMap<Classifier, String> parents = new HashMap<Classifier, String>();

		generatePaths(strs, cl, "", "/", parents, cl.getName());
		return strs;

	}

	/**
	 * Get the attribute paths for a classifier
	 * 
	 * @param strs
	 *            paths of attributes, used to add new paths to
	 * @param cl
	 *            Classifier to find new paths with
	 * @param prefix
	 *            Prefix for the new paths (added before "/")
	 * @param qualifier
	 *            qualifier for the new paths (added after "/" )
	 * @param parents
	 *            classes which are "inclusion" parents to this attributes ,
	 *            with their path. Used to identify recursion
	 * @param propname
	 *            name of the property attribute
	 * @throws NEMMappingError
	 */
	public static void generatePaths(Vector<String> strs, Classifier cl,
			String prefix, String qualifier,
			HashMap<Classifier, String> parents, String propname)
			throws NEMMappingError {

		// check for recursion
		if (parents.containsKey(cl)) {
			// recursion, stop going deeper and add reference to paths
			strs.add(prefix + qualifier + "@->" + parents.get(cl));
			return;

		}
		HashMap<Classifier, String> newParents = new HashMap<Classifier, String>();
		newParents.putAll(parents);
		newParents.put(cl, prefix);

		// get classes which extend this class
		Vector<Vector<Classifier>> subCls = getAllSubTypes(cl);

		// scan through all the attributes of this class (including it's
		// superclasses)
		for (TypedElement p : cl.getAllAttributes()) {
			// if this attribute is of type class
			if (p.getType() instanceof Classifier) {

				String newPrefix = prefix + propname + qualifier;

				strs.add(newPrefix + p.getName());
				generatePaths(strs, (Classifier) p.getType(), newPrefix, "/",
						newParents, p.getName());
			} else {// NOT a class type, just record the attribute.
				strs.add(prefix + propname + qualifier + p.getName());
			}
		}
		// scan through all nested classifiers if this is a Class
		if (cl instanceof Class) {
			Class ccl = (Class) cl;
			for (Classifier c : ccl.getNestedClassifiers()) {

				// Add a qualifier, otherwise unchanged
				generatePaths(strs, c, prefix, qualifier + "[" + c.getName()
						+ "]", newParents, propname);

			}
		}

		// scan through the attributes of this class's subtypes
		for (Vector<Classifier> subCl : subCls) {
			String subClStr = subClassToString(subCl);
			Classifier genCl = subCl.lastElement();

			// scan through the ALL attributes of this class (including those of
			// superclasses, covered above)
			// Note this could be switched back to getOwnedAttributes
			EList<TypedElement> ownAttrs;
			if (genCl instanceof DataType) {
				// When java 8 is used, lamdas can hide this cast.
				ownAttrs = (EList) ((DataType) genCl).getAllAttributes();
			} else if (genCl instanceof Class) {
				// When java 8 is used, lamdas can hide this cast.
				ownAttrs = (EList) ((Class) genCl).getAllAttributes();
			} else {
				// for non dataType or class subtypes, skip these
				break;
			}

			for (TypedElement p : ownAttrs) {
				// if this attribute is of type class
				if (p.getType() instanceof Classifier) {

					String newPrefix = prefix + subClStr + propname + qualifier;
					strs.add(newPrefix + p.getName());
					generatePaths(strs, (Classifier) p.getType(), newPrefix,
							"/", newParents, p.getName());
				} else {// NOT a class type, just record the attribute.
					strs.add(prefix + subClStr + propname + qualifier
							+ p.getName());
				}
			}
		}

	}

	/**
	 * Finds all the subtypes (and subtypes of subtypes etc) of a Classifer
	 * 
	 * @param cl
	 *            Classifier to check
	 * @return a list of subtype hierarchies
	 * @throws NEMMappingError
	 */
	private static Vector<Vector<Classifier>> getAllSubTypes(Classifier cl)
			throws NEMMappingError {
		Vector<Vector<Classifier>> ret = new Vector<Vector<Classifier>>();
		EList<DirectedRelationship> tRels = cl.getTargetDirectedRelationships();
		for (DirectedRelationship rel : tRels) {
			// filter for only the generalisations.
			if (rel instanceof Generalization) {
				EList<Element> genCls = rel.getSources();
				if (genCls.size() != 1
						|| (!(genCls.get(0) instanceof Classifier))) {
					throw new NEMMappingError(
							"Genraliation Source with more than 1 entry");
				}
				Classifier genCl = (Classifier) genCls.get(0);
				Vector<Classifier> toAdd = new Vector<Classifier>();
				toAdd.add(genCl);
				ret.add(toAdd);
				for (Vector<Classifier> subCl : getAllSubTypes(genCl)) {
					// for each subclass of this add an entry for (base,
					// subclass, subclass ...)
					Vector<Classifier> base = new Vector<Classifier>();
					base.add(genCl);
					base.addAll(subCl);
					ret.add(base);
				}

			}

		}

		return ret;
	}

	/**
	 * processes a subtype hierarchy outputs a path string
	 * 
	 * @param subClasses
	 *            a hierarchy of subtypes
	 * @return a formatted path string representing the hierarchy.
	 */
	private static String subClassToString(Vector<Classifier> subClasses) {
		StringBuffer pre = new StringBuffer();
		StringBuffer post = new StringBuffer();
		for (Classifier cl : subClasses) {
			pre.append("(");
			pre.append(cl.getName());
			post.append(")");

		}
		return pre.toString() + post.toString();

	}

	/**
	 * takes a list of mapping operation elements and loads these into a RSA UML
	 * Model
	 * 
	 * @param moes
	 *            the mapping operation elements to load
	 * @throws NEMMappingError
	 */
	public static void processMOES(final Vector<MappingOperationElement> moes)
			throws NEMMappingError {
		// make a change
		TransactionalEditingDomain ted = UMLModeler.getEditingDomain();
		final ResourceSet rs = ted.getResourceSet();

		passBack = null;
		ted.getCommandStack().execute(
				new RecordingCommand(ted, "Undo Process Mapping Template") {

					@Override
					protected void doExecute() {
						for (MappingOperationElement moe : moes) {
							try {

								ModelUtil.processMOE(moe, rs);
							} catch (NEMMappingError e) {
								// use this to pass back errors
								setPassBack(e);
							}
						}

					}
				});
		if (passBack != null) {
			throw passBack;
		}

	}

	/**
	 * Set the passback error for inner classes to call.
	 * 
	 * @param pb
	 */
	public static void setPassBack(NEMMappingError pb) {
		passBack = pb;
	}

	/**
	 * Process a single mapping operation element, add it to the RSA Model
	 * 
	 * @param moe
	 *            Mapping Operation Element to load
	 * @param rs
	 *            resource set where existing resources are and new resources
	 *            are loaded.
	 * @throws NEMMappingError
	 */
	public static void processMOE(MappingOperationElement moe, ResourceSet rs)
			throws NEMMappingError {

		URI suri = moe.getSourceAttr();
		NamedElement sObj = getNamedElement(rs, suri);
		URI turi = moe.getTargetAttr();
		NamedElement tObj = getNamedElement(rs, turi);
		Usage usage;
		if (moe.getDirection() == MappingOperationElement.PUSHDIR) {
			// push from source to target
			usage = sObj.createUsage(tObj);

		} else {
			// this is a pull so reverse the relationship
			usage = tObj.createUsage(sObj);
		}

		Stereotype st = usage.getApplicableStereotype(ProfileUtil.PROFILE_NAME);

		if (st == null) {
			throw new NEMMappingError(
					"Could not apply the "
							+ ProfileUtil.PROFILE_NAME
							+ " sterotype to this model (try setting this Class to External in the template): ");
		}
		usage.applyStereotype(st);
		usage.setValue(st, ProfileUtil.PP_PUSH,
				moe.getDirection() == MappingOperationElement.PUSHDIR);
		usage.setValue(st, ProfileUtil.PP_CONDITION, moe.getCondition());
		usage.setValue(st, ProfileUtil.PP_TRANSFORMATION,
				moe.getTransformation());
		usage.setValue(st, ProfileUtil.PP_MAPPING_OPERATION,
				moe.getMappingOperation());
		usage.setValue(st, ProfileUtil.PP_SERVICE_OPERATION,
				moe.getServiceOperation());
		usage.setValue(st, ProfileUtil.PP_SOURCE_MSG_PATH, moe.getSourcePath());
		usage.setValue(st, ProfileUtil.PP_TAREGT_MSG_PATH, moe.getTargetPath());

	}

	/**
	 * Load a NamedElement Object from a URI, using a provided resource set
	 * 
	 * @param rs
	 *            resource set to use to load the element
	 * @param objURI
	 *            URI of the element in the RSA UML Model
	 * @return The element which was found
	 * @throws NEMMappingError
	 */
	private static NamedElement getNamedElement(ResourceSet rs, URI objURI)
			throws NEMMappingError {
		URI baseURI = objURI.trimFragment();
		Factory factory = Resource.Factory.Registry.INSTANCE
				.getFactory(baseURI);
		rs.getResourceFactoryRegistry().getExtensionToFactoryMap()
				.put("emx", factory);
		Resource res;
		try {
			res = rs.getResource(baseURI, true);
		} catch (WrappedException e) {
			throw new NEMMappingError("Problem loading a URI:" + baseURI, e);
		}

		try {
			res.load(new HashMap<Object, Object>());
		} catch (IOException e) {
			throw new NEMMappingError("Problem loading element "
					+ objURI.toString(), e);

		}

		EObject obj = res.getEObject(objURI.fragment());
		NamedElement eObj;
		if (obj instanceof NamedElement) {
			eObj = (NamedElement) obj;
		} else {
			throw new NEMMappingError(
					"Could not resolve URI to a NamedElement "
							+ objURI.toString());
		}

		return eObj;

	}

	/**
	 * Scans through Mapping Element Operations addings the URIs of the sources
	 * and target elements by using the base URI and the path.
	 * 
	 * @param moes
	 *            Mapping Element Operations to update
	 * @throws NEMMappingError
	 */
	public static void updateMOEAttrURIs(Vector<MappingOperationElement> moes)
			throws NEMMappingError {
		if (moes.size() > 0) {
			Factory factory = Resource.Factory.Registry.INSTANCE
					.getFactory(moes.get(0).getSourceBase());
			ResourceSet rs = new ResourceSetImpl();
			rs.getResourceFactoryRegistry().getExtensionToFactoryMap()
					.put("emx", factory);

			for (MappingOperationElement moe : moes) {
				moe.setSourceAttr(findRelativeURI(moe.getSourceBase(),
						moe.getSourcePath(), rs));
				moe.setTargetAttr(findRelativeURI(moe.getTargetBase(),
						moe.getTargetPath(), rs));
			}
		}

	}

	/**
	 * Finds a URI of an attribute by navigating from a start URI along a path
	 * 
	 * @param startURI
	 *            URI to start navigating from
	 * @param sourcePath
	 *            path to navigate to find element
	 * @param rs
	 *            resource set to use for finding the URIs
	 * @return URI of found attribute
	 * @throws NEMMappingError
	 */
	private static URI findRelativeURI(URI startURI, String sourcePath,
			ResourceSet rs) throws NEMMappingError {
		String[] sourceParts = sourcePath.split("\\/");
		Resource res;
		URI baseURI = startURI.trimFragment();
		try {
			res = rs.getResource(baseURI, true);
		} catch (WrappedException e) {
			throw new NEMMappingError("Problem loading a URI:" + baseURI, e);
		}
		try {
			res.load(new HashMap<Object, Object>());
		} catch (IOException e) {
			throw new NEMMappingError("Error reading " + baseURI, e);
		}
		EObject eObj = res.getEObject(startURI.fragment());
		if (!(eObj instanceof Classifier)) {
			throw new NEMMappingError("Base URL was not a class, "
					+ startURI.toString());
		}
		Classifier clasStart = (Classifier) eObj;
		if (!clasStart.getName().equals(sourceParts[0])) {
			throw new NEMMappingError(
					"Base Class and Base Path did not match, "
							+ clasStart.getName() + "=/=" + sourceParts[0]);
		}
		Classifier clasEnd = clasStart; // this variable will contain the
										// Classes as
		// we work down the path.
		// TODO consider a recursive approach to handle duplicate names.
		TypedElement finalProp = null;
		for (int n = 1; n < sourceParts.length; n++) {
			String sourcePart = sourceParts[n];
			Classifier clasPart;
			// is this a Nested Class
			if (sourcePart.contains("[")) {
				String nClassName = sourcePart.substring(
						sourcePart.indexOf("[") + 1, sourcePart.indexOf("]"));
				if (clasEnd instanceof Class) {
					Class cclasEnd = (Class) clasEnd;
					boolean found = false;
					EList<Classifier> nestedC = cclasEnd.getNestedClassifiers();
					for (Classifier nestC : nestedC) {

						if (nestC.getName().equals(nClassName)) {
							// move into the nested class
							clasEnd = nestC;
							// remove the nested class from the name
							sourcePart = sourcePart.replace("[" + nClassName
									+ "]", "");
							found = true;

						}
					}
					if (!found) {
						throw new NEMMappingError("Non Class not found "
								+ sourcePath + " in " + sourcePart);
					}
				} else {
					// Error non Class containing nested class!
					throw new NEMMappingError(
							"Non Class contains nested Classes! " + sourcePath
									+ " in " + sourcePart);
				}
			}

			Classifier propClass = null;
			// Is this a subtype?
			if (sourcePart.startsWith("(")) {
				// Now scan the class for its properties to find the next Class
				// or
				// Primitive in the path
				String propPart = sourcePart.substring(
						sourcePart.lastIndexOf(")") + 1, sourcePart.length());

				boolean found2 = false;
				for (TypedElement prop : clasEnd.getAllAttributes()) {
					if (prop.getName().equals(propPart)) {
						found2 = true;
						if (!(prop.getType() instanceof Classifier)) {
							if (n < sourceParts.length - 1) {
								throw new NEMMappingError("The attribute "
										+ prop.getName()
										+ " did not have a Class as a type in "
										+ sourcePath);
							}
						} else {
							propClass = (Classifier) prop.getType();
						}
						finalProp = prop;
					}

				}
				if (found2 == false) {
					throw new NEMMappingError("did not find, " + propPart
							+ " in " + sourcePath);
				}
				// This is a subtype, split it up into all the subtypes
				String[] subTypes = sourcePart.substring(1,
						sourcePart.lastIndexOf(")")).split("\\(");
				Classifier fClas = propClass; // This will trace down the
												// subtypes
				for (String subType : subTypes) {
					// clean the name;
					String subTypeName = subType.replace("(", "").replace(")",
							"");

					// find a subclass of this
					Classifier fClasNext = null;
					boolean found3 = false;
					for (DirectedRelationship ceRel : fClas
							.getTargetDirectedRelationships()) {
						if (ceRel.getSources().size() > 0) {
							Element cnElm = ceRel.getSources().get(0);
							if (cnElm instanceof Classifier
									&& ceRel instanceof Generalization) {
								fClasNext = (Classifier) cnElm;
								if (fClasNext.getName().equals(subTypeName)) {
									found3 = true;
									break;
								}
							}
							// ignore none Classifiers
						}
					}
					if (found3 == false) {
						throw new NEMMappingError("Did not find " + subTypeName
								+ " as a sub type of " + clasEnd.getName()
								+ " when processing " + sourcePath);
					}
					//now we have the true class use this.
					propClass = fClasNext;
					fClas = fClasNext;
				}
			} else { // from "if a subtype" 
				//this is not a subtype
				clasPart = clasEnd;

				boolean found = false;
				// Now scan the class for its properties to find the next Class
				// or
				// Primitive in the path

				for (TypedElement prop : clasPart.getAllAttributes()) {
					if (prop.getName().equals(sourcePart)) {
						found = true;
						if (!(prop.getType() instanceof Classifier)) {
							if (n < sourceParts.length - 1) {
								throw new NEMMappingError("The attribute "
										+ prop.getName()
										+ " did not have a Class as a type in "
										+ sourcePath);
							}
						} else {
							propClass = (Classifier) prop.getType();
						}
						finalProp = prop;
						break;
					}

				}
				if (found == false) {
					throw new NEMMappingError("did not find, " + sourcePart
							+ " in " + sourcePath);
				}
			}
			clasEnd = propClass;
		}

		return EcoreUtil.getURI(finalProp);
	}

	/**
	 * gets the existing Mapping Operations on a class its subclasses and
	 * attribute classes,
	 * 
	 * @param clas
	 *            Classifier to search for mapping operations
	 * @return map of paths to mapping operations.
	 * @throws NEMMappingError
	 */
	public static Map<String, Usage> getOperationsOnClass(Classifier clas)
			throws NEMMappingError {
		Vector<Classifier> parents = new Vector<Classifier>();
		return getOperationsOnClass(clas, parents, clas.getName());
	}

	/**
	 * gets the existing Mapping Operations on a class its subclasses and
	 * attribute classes,
	 * 
	 * @param clas
	 *            Classifier to search for mapping operations
	 * @param parents
	 *            Parent classes , used to stop runaway recursion
	 * @return a map of paths to mapping operations.
	 * @throws NEMMappingError
	 */

	public static Map<String, Usage> getOperationsOnClass(Classifier clas,
			Vector<Classifier> parents, String baseClassName)
			throws NEMMappingError {
		Vector<Classifier> newParents = new Vector<Classifier>();
		newParents.addAll(parents);
		newParents.add(clas);
		Map<String, Usage> usages = new HashMap<String, Usage>();
		// stop if recursing over classes already in the list of
		// inclusion/subtype parent classes
		if (parents.contains(clas)) {
			return usages;
		}
		// When java 8 is used, lamdas can hide this cast.
		EList<TypedElement> attrs = (EList) clas.getAllAttributes();
		for (TypedElement prop : attrs) {

			// targets
			for (DirectedRelationship tdr : prop
					.getTargetDirectedRelationships()) {
				// find usages
				if (tdr instanceof Usage) {
					Usage u = (Usage) tdr;
					Stereotype str = u
							.getAppliedStereotype(ProfileUtil.PROFILE_NAME);

					if (str != null) {
						// Check class name matches targetClass which is 1st
						// part of the path
						String tarPath = u.getValue(str,
								ProfileUtil.PP_TAREGT_MSG_PATH).toString();
						String clasName = tarPath.substring(0,
								tarPath.indexOf("/"));
						if (baseClassName.equals(clasName)) {
							usages.put(
									u.getValue(str,
											ProfileUtil.PP_SERVICE_OPERATION)
											.toString()
											+ ","
											+ u.getValue(
													str,
													ProfileUtil.PP_MAPPING_OPERATION)
													.toString(), u);
						}

					}
				}

			}
			// sources
			for (DirectedRelationship sdr : prop
					.getSourceDirectedRelationships()) {
				if (sdr instanceof Usage) {
					Usage u = (Usage) sdr;
					Stereotype str = u
							.getAppliedStereotype(ProfileUtil.PROFILE_NAME);
					if (str != null) {

						// Check class name matches targetClass which is 1st
						// part of the path
						String tarPath = u.getValue(str,
								ProfileUtil.PP_TAREGT_MSG_PATH).toString();
						String clasName = tarPath.substring(0,
								tarPath.indexOf("/"));
						if (baseClassName.equals(clasName))
							;
						{
							usages.put(
									u.getValue(str,
											ProfileUtil.PP_SERVICE_OPERATION)
											.toString()
											+ ","
											+ u.getValue(
													str,
													ProfileUtil.PP_MAPPING_OPERATION)
													.toString(), u);
						}

					}
				}

			}
			// parse included attribute type
			if (prop.getType() instanceof Classifier) {
				Classifier pCl = (Classifier) prop.getType();
				Map<String, Usage> pUsages = getOperationsOnClass(pCl,
						newParents, baseClassName);
				usages.putAll(pUsages);
			}

		}

		// parse all subtypes
		for (Vector<Classifier> subtypeH : getAllSubTypes(clas)) {
			for (Classifier subtype : subtypeH) {
				Map<String, Usage> stUsages = getOperationsOnClass(subtype,
						newParents, baseClassName);
				usages.putAll(stUsages);
			}
		}

		return usages;

	}

	/**
	 * Get the Usages on the a class attributes and its inclusion /subtype tree
	 * of classes which are stereotyped with the NEM mapping TOR and have
	 * matching service operation, mapping operation
	 * 
	 * @param clas
	 *            Classifier to search
	 * @param serviceOperation
	 *            Service operation to match
	 * @param mappingOperation
	 *            Mapping operation to match
	 * @param path
	 *            path the target Mappings must start with to be selected
	 * @return the set of found usages
	 * @throws NEMMappingError
	 */
	public static Vector<Usage> getUsagesInMapping(Classifier clas,
			String serviceOperation, String mappingOperation, String path)
			throws NEMMappingError {
		Vector<Classifier> parentTypes=new Vector<Classifier>();
		return getUsagesInMapping(clas,serviceOperation,mappingOperation,path,parentTypes);
	}
	
	private static Vector<Usage> getUsagesInMapping(Classifier clas,
				String serviceOperation, String mappingOperation, String path, Vector<Classifier> parentTypes)
				throws NEMMappingError {
		Vector<Classifier> newParentTypes;
	
		Vector<Usage> usages = new Vector<Usage>();
		if (parentTypes==null)
		{
			//previous flow spotted recursion and set to null stop here.
			return usages;
		}
		if (parentTypes.contains(clas))
		{
			//recursion do not go deeper than this level. Set newParentTypes to null so next invocation exits.
			newParentTypes=null;
		}else
		{
			//duplicate the parent types and add this
			// cannot simply add this type as this is a recursively called function & java is pass by reference.
			newParentTypes = new Vector<Classifier>(parentTypes);
			newParentTypes.add(clas);
		}
		// When java 8 is used, lamdas can hide this cast.
		EList<TypedElement> attrs = (EList) clas.getAllAttributes();
		// do nested types
		if (clas instanceof Class) {
			Class cclas = (Class) clas;
			for (Classifier nc : cclas.getNestedClassifiers()) {
				Vector<Usage> ncUses = getUsagesInMapping(nc, serviceOperation,
						mappingOperation, path + "[" + nc.getName() + "]",newParentTypes);
				usages.addAll(ncUses);
			}
		}

		// do properties
		for (TypedElement prop : attrs) {

			for (DirectedRelationship tdr : prop
					.getTargetDirectedRelationships()) {
				getUsagesFromTR(tdr, mappingOperation, serviceOperation,
						usages, path+prop.getName());

			}
			for (DirectedRelationship tdr : prop
					.getSourceDirectedRelationships()) {
				getUsagesFromTR(tdr, mappingOperation, serviceOperation,
						usages, path+prop.getName());

			}
			if (prop.getType() instanceof Classifier) {
				Classifier typesClass = (Classifier) prop.getType();
				Vector<Usage> typesUsages = getUsagesInMapping(typesClass,
						serviceOperation, mappingOperation,
						path + prop.getName() + "/",newParentTypes);
				usages.addAll(typesUsages);

				// do subtypes
				for (Vector<Classifier> subs : getAllSubTypes(typesClass)) {
					String subPath = path + ModelUtil.subClassToString(subs)
							+ prop.getName() + "/";

					Vector<Usage> subTypesUsages = getUsagesInMapping(
							subs.lastElement(), serviceOperation,
							mappingOperation, subPath,newParentTypes);
					usages.addAll(subTypesUsages);
				}
			}

		}
		return usages;
	}

	/**
	 * @param tdr
	 * @param mappingOperation
	 * @param serviceOperation
	 * @param usages
	 * @param path
	 */
	private static void getUsagesFromTR(DirectedRelationship tdr,
			String mappingOperation, String serviceOperation,
			Vector<Usage> usages, String path) {

		if (tdr instanceof Usage) {
			Usage u = (Usage) tdr;
			Stereotype str = u.getAppliedStereotype(ProfileUtil.PROFILE_NAME);

			if (str != null) {
				String mapOp = u
						.getValue(str, ProfileUtil.PP_MAPPING_OPERATION)
						.toString();
				String serOp = u
						.getValue(str, ProfileUtil.PP_SERVICE_OPERATION)
						.toString();
				String targetMsgPath = u.getValue(str,
						ProfileUtil.PP_TAREGT_MSG_PATH).toString();
				if (mapOp.equals(mappingOperation)
						& serOp.equals(serviceOperation)) {
					// check the context
					if (targetMsgPath.equals(path)) {
						usages.add(u);
					}
				}

			}
		}
	}

	/**
	 * extracts mapping the base class info from a set of usages
	 * 
	 * @param usagesToStore
	 *            usages representing a mapping
	 * @return a set of base class info, for source and destination base classes
	 * @throws NEMMappingError
	 */
	public static Vector<ClassInfo> getClassInfo(Vector<Usage> usagesToStore)
			throws NEMMappingError {
		Vector<ClassInfo> ret = new Vector<ClassInfo>();
		HashMap<String, Usage> mapTarsToExampleUsage = new HashMap<String, Usage>();
		HashMap<String, Usage> mapSorsToExampleUsage = new HashMap<String, Usage>();
		// Scan all of the usages identifying each base class.
		for (Usage u : usagesToStore) {

			// This approach assumes that the base class contains an attribute
			// with a mapping for each of the involved classes.
			Stereotype str = u.getAppliedStereotype(ProfileUtil.PROFILE_NAME);
			String tmp = u.getValue(str, ProfileUtil.PP_TAREGT_MSG_PATH)
					.toString();
			String tBaseClass = tmp.substring(0, tmp.indexOf("/"));
			// is this a base attribute?
			if (tmp.indexOf("/") == tmp.lastIndexOf("/")) {
				mapTarsToExampleUsage.put(tBaseClass, u);
			} else {
				// Add this only if there is no entry already, but no example as
				// this is not an attribute of the base class
				if (!mapTarsToExampleUsage.containsKey(tBaseClass)) {
					mapTarsToExampleUsage.put(tBaseClass, u);
				}
			}

			String smp = u.getValue(str, ProfileUtil.PP_SOURCE_MSG_PATH)
					.toString();
			String sBaseClass = smp.substring(0, smp.indexOf("/"));
			if (smp.indexOf("/") == smp.lastIndexOf("/")) {
				mapSorsToExampleUsage.put(sBaseClass, u);
			} else {
				// Add this only if there is no entry already, but no example as
				// this is not an attribute of the base class
				if (!mapSorsToExampleUsage.containsKey(sBaseClass)) {
					mapSorsToExampleUsage.put(sBaseClass, u);
				}
			}

		}// end for (Usage u : usagesToStore)

		// Error checking
		if (mapTarsToExampleUsage.size() == 0) {
			// need one target
			throw new NEMMappingError("Did not find a target to map to");

		} else if (mapTarsToExampleUsage.size() > 1) {
			throw new NEMMappingError("More than one target to map to");
		}
		if (mapSorsToExampleUsage.size() == 0) {
			// need one target
			throw new NEMMappingError("Did not find a source to map from");

		}
		// Capture the target classes
		// this will be a single entry
		Entry<String, Usage> target = mapTarsToExampleUsage.entrySet()
				.iterator().next();

		if (target == null) {
			throw new NEMMappingError(
					"No attributes under base class found for targets");
		}
		ClassInfo tarci = new ClassInfo();
		tarci.setName("target_" + target.getKey());
		Stereotype str = target.getValue().getAppliedStereotype(
				ProfileUtil.PROFILE_NAME);
		Classifier realTarget;
		if ((boolean) target.getValue().getValue(str, ProfileUtil.PP_PUSH)) {
			TypedElement propTarget = (TypedElement) target.getValue()
					.getTargets().iterator().next();
			realTarget = (Classifier) propTarget.getOwner();
			tarci.setExternal(true); // a safe guess but could be false

		} else {// pull
			TypedElement propTarget = (TypedElement) target.getValue()
					.getSources().iterator().next();
			realTarget = (Classifier) propTarget.getOwner();
			tarci.setExternal(false); // pulls are only required if true source
										// is external, so the target must be
										// internal
		}
		tarci.setUri(EcoreUtil.getURI(realTarget));
		ret.add(tarci);
		// Capture the source classes
		for (Entry<String, Usage> source : mapSorsToExampleUsage.entrySet()) {

			ClassInfo sorci = new ClassInfo();
			sorci.setName("source_" + source.getKey());
			Stereotype strS = source.getValue().getAppliedStereotype(
					ProfileUtil.PROFILE_NAME);
			Classifier realSource;
			if ((boolean) source.getValue().getValue(strS, ProfileUtil.PP_PUSH)) {
				TypedElement propSource = (TypedElement) source.getValue()
						.getSources().iterator().next();
				realSource = (Classifier) propSource.getOwner();
				sorci.setExternal(false); // a push MUST come from an
											// internal source

			} else {// pull
				TypedElement propSource = (TypedElement) source.getValue()
						.getTargets().iterator().next();
				realSource = (Classifier) propSource.getOwner();
				sorci.setExternal(true); // pulls are only required if true
											// source is external
			}
			sorci.setUri(EcoreUtil.getURI(realSource));
			ret.add(sorci);

		}

		return ret;
	}

	/**
	 * Get the Mapping Operation Elements from a set of usages, Note does not
	 * populate the URIs
	 * 
	 * @param usagesToStore
	 *            set of Usages
	 * @return a set of Mapping Operation Elements
	 */
	public static Vector<MappingOperationElement> getMOEs(
			Vector<Usage> usagesToStore) {
		Vector<MappingOperationElement> ret = new Vector<MappingOperationElement>();
		for (Usage u : usagesToStore) {
			MappingOperationElement moe = new MappingOperationElement();
			Stereotype st = u.getAppliedStereotype(ProfileUtil.PROFILE_NAME);
			moe.setDirection(((boolean) u.getValue(st, ProfileUtil.PP_PUSH)) ? MappingOperationElement.PUSHDIR
					: MappingOperationElement.PULLDIR);
			Object cond = u.getValue(st, ProfileUtil.PP_CONDITION);
			moe.setCondition(cond != null ? cond.toString() : null);
			Object trans = u.getValue(st, ProfileUtil.PP_TRANSFORMATION);
			moe.setTransformation(trans != null ? trans.toString() : null);
			moe.setMappingOperation(u.getValue(st,
					ProfileUtil.PP_MAPPING_OPERATION).toString());
			moe.setServiceOperation(u.getValue(st,
					ProfileUtil.PP_SERVICE_OPERATION).toString());
			moe.setSourcePath(u.getValue(st, ProfileUtil.PP_SOURCE_MSG_PATH)
					.toString());
			moe.setTargetPath(u.getValue(st, ProfileUtil.PP_TAREGT_MSG_PATH)
					.toString());
			moe.setTargetKey("target_"
					+ moe.getTargetPath().substring(0,
							moe.getTargetPath().indexOf("/")));
			moe.setSourceKey("source_"
					+ moe.getSourcePath().substring(0,
							moe.getSourcePath().indexOf("/")));

			ret.add(moe);

		}
		return ret;
	}

	/**
	 * Remove/destroy a set of Usages
	 * 
	 * @param usages
	 *            the set of usages to destroy
	 * @param undoName
	 *            the name of this operation in the undo/redo queue.
	 */
	public static void deleteUsages(final Vector<Usage> usages, String undoName) {
		// make a change
		TransactionalEditingDomain ted = UMLModeler.getEditingDomain();

		ted.getCommandStack().execute(new RecordingCommand(ted, undoName) {
			@Override
			protected void doExecute() {
				for (Usage u : usages) {

					u.destroy();

				}

			}
		});

	}

}

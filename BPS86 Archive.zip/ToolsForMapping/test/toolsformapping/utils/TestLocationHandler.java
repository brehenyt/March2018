package toolsformapping.utils;

import java.io.File;
import java.io.FileInputStream;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class TestLocationHandler {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {

		File f=new File("Example.xml");
		FileInputStream fis = new FileInputStream(f);
		Document doc=LocationHandler.parse(fis); 
		
		Element root = doc.getDocumentElement();
		printElem(root);
		NodeList nl = root.getElementsByTagName("child");
		printElem((Element) nl.item(0));
		
		System.out.println("Name spaces");
		
		File f2=new File("ExampleNS.xml");
		FileInputStream fisns = new FileInputStream(f2);
		Document docns=LocationHandler.parse(fisns); 
		
		Element rootns = docns.getDocumentElement();
		printElem(rootns);
		NodeList nlns = rootns.getElementsByTagNameNS("hhtp:/example.com/","child");
		printElem((Element) nlns.item(0));

		
		System.out.println("finished");

	}
	
	private static void printElem(Element e)
	{
		System.out.println(e.getNodeName());
		System.out.println(e.getUserData(LocationHandler.UD_STARTLINE));
		System.out.println(e.getUserData(LocationHandler.UD_STARTCOL));
		System.out.println(e.getUserData(LocationHandler.UD_ENDLINE));
		System.out.println(e.getUserData(LocationHandler.UD_ENDCOL));
		
	}

}
